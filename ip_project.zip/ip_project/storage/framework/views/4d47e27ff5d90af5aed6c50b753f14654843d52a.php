<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow|Roboto" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/head-hunt.css')); ?>">
			
    <title>Bureu Profiler | BP</title>

  </head>

  <body> 
		<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 
<!-- ------------------------------------------------------------------------------ -->

  	<!-- ------------------------------ Contact us Page------------------------------------------------------------------ -->
		<img id="feedback_button" src="head-hunt-images/feedback.png" data-toggle="modal" data-target="#myModal" alt="message">

		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" style="margin-right: 5px;">&times;</button>
						<h5 class="modal-title">
								Fill in the form and leave the message, we will respond as soon as possible.
						</h5>
					</div>
					<div class="modal-body">
							<form action="/action_page.php">
								<div class="form-group">
									<input type="name" class="form-control" id="name" placeholder="Enter your name">
								</div>
								<div class="form-group">
									<input type="email" class="form-control" id="email" placeholder="Enter your email address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Please,fill correctly" required>
								</div>
								<div class="form-group">
										<input type="text" class="form-control" id="text" placeholder="Subject of your message">
								</div>
								<div class="form-group">
										<textarea class="form-control" rows="5" id="comment" placeholder="Enter your message"></textarea>
								</div>
								<button type="submit" class="btn btn-default">Submit</button>
							</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
				
			</div>
		</div>
	
	<!-- -------------------------------------------------------------------------------------------- -->

<!-- --------------------------------HASHTAGS---------------------------------------- -->
  <div id="hashtags">

    <h2>Communities</h2>

    <ul id="hashtag_list">
      <li><a href="#" class="item">Finances</a></li>
      <li><a href="#" class="item">Transportation</a></li>
      <li><a href="#" class="item">Architecture</a></li>
      <li><a href="#" class="item">Construction</a></li>
      <li><a href="#" class="item">Manufacturing</a></li>
      <li><a href="#" class="item">IT</a></li>
      <li><a href="#" class="item">Engineering</a></li>
      <li><a href="#" class="item">Logistics</a></li>
      <li><a href="#" class="item">Marketing</a></li>
      <li><a href="#" class="item">Education</a></li>
      <li><a href="#" class="item">Catering</a></li>
      <li><a href="#" class="item">Jurisprudence</a></li>
      <li><a href="#" class="item">Tourism</a></li>
      <li><a href="#" class="item">Journalism</a></li>
      <li><a href="#" class="item">Design</a></li>
    </ul>
  </div>

  <div id="collapsed_hashtags">

  	<div id="accordion">
    	<div class="card">
      		<div class="card-header">
	        	<a class="card-link" data-toggle="collapse" href="#collapseOne">

	          		<h2>Communities</h2>
	          		<i class="arrow down"></i>
	        	</a>
      		</div>
      		<div id="collapseOne" class="collapse show" data-parent="#accordion">
        	<div class="card-body">
          		<ul id="hashtag_list">
			      <li><a href="#" class="item">Finances</a></li>
			      <li><a href="#" class="item">Transportation</a></li>
			      <li><a href="#" class="item">Architecture</a></li>
			      <li><a href="#" class="item">Construction</a></li>
			      <li><a href="#" class="item">Manufacturing</a></li>
			      <li><a href="#" class="item">IT</a></li>
			      <li><a href="#" class="item">Engineering</a></li>
			      <li><a href="#" class="item">Logistics</a></li>
			      <li><a href="#" class="item">Marketing</a></li>
			      <li><a href="#" class="item">Education</a></li>
			      <li><a href="#" class="item">Catering</a></li>
			      <li><a href="#" class="item">Jurisprudence</a></li>
			      <li><a href="#" class="item">Tourism</a></li>
			      <li><a href="#" class="item">Journalism</a></li>
			      <li><a href="#" class="item">Design</a></li>
			    </ul>
        	</div>
        	</div>
      	</div>
    </div>
 
  </div>
<!-- ------------------------------------------------------------------------------------ -->

<!-- -------------------------------MAIN BODY-------------------------------------------- -->
  <div id="main">
  	<h2>All profiles</h2>
  		<a href="#">
  			<div class="info">
  				<div class="profile_img_container"><img class="avatar" src="<?php echo e(asset('head-hunt-images/male_avatar.png')); ?>" alt="Avatar"></div>
  				<div class="description">
  					<ul>
  						<li class="name">Shohruh <span>Shohnazarov</span></li>
  						<li class="job_position">Web development, Web design, PHP, MySql</li>
  						<li class="skills">
  							Full-stack web developer with profound knowledge on web technologies. Have 3 years of experience and can fully manage one project and work with different frameworks. Also can work with team and very strict with deadlines.
  						</li>
  					</ul>
  				</div>
  			</div>
  		</a>
  		<a href="#">
  			<div class="info">
  				<div class="profile_img_container"><img class="avatar" src="head-hunt-images/female_avatar.jpg" alt="Avatar"></div>
  				<div class="description">
  					<ul>
  						<li class="name">Scarlett <span>Johansson</span></li>
  						<li class="job_position">Actress</li>
  						<li class="skills">
  							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, nisi animi ad voluptate ratione cupiditate odit natus, non, fuga hic, asperiores aspernatur corrupti architecto molestias quos! Repudiandae quasi obcaecati dolore.
  						</li>
  					</ul>
  				</div>
  			</div>
  		</a>
  		<a href="#">
  			<div class="info">
  				<div class="profile_img_container"><img class="avatar" src="head-hunt-images/female_avatar.jpg" alt="Avatar"></div>
  				<div class="description">
  					<ul>
  						<li class="name">Elizabeth <span>Olsen</span></li>
  						<li class="job_position">Web development, Web design, PHP, MySql</li>
  						<li class="skills">
  							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate corporis incidunt assumenda ad culpa asperiores dolorum quae ducimus, natus dolore molestias quisquam enim quibusdam provident totam autem velit cum. In?
  						</li>
  					</ul>
  				</div>
  			</div>
  		</a>
  		<a href="#">
  			<div class="info">
  				<div class="profile_img_container"><img class="avatar" src="head-hunt-images/male_avatar.png" alt="Avatar"></div>
  				<div class="description">
  					<ul>
  						<li class="name">Robert <span>Downey Jr</span></li>
  						<li class="job_position">Actor</li>
  						<li class="skills">
  							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut possimus illo, maxime quidem quas provident error, accusantium nesciunt dignissimos, cumque corporis temporibus iure sunt. Illum sint atque ullam quis placeat.
  							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam enim accusantium, reiciendis corporis architecto perspiciatis dolorum assumenda quaerat soluta consequuntur at consectetur. Dicta, cum, unde? Animi facilis tenetur at aperiam.
  						</li>
  					</ul>
  				</div>
  			</div>
  		</a>
  		<a href="#">
  			<div class="info">
  				<div class="profile_img_container"><img class="avatar" src="head-hunt-images/male_avatar.png" alt="Avatar"></div>
  				<div class="description">
  					<ul>
  						<li class="name">Sherali <span>Joraev</span></li>
  						<li class="job_position">Singer</li>
  						<li class="skills">
  							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero, inventore consequuntur eligendi quo quasi eos dignissimos pariatur. Aspernatur ducimus qui mollitia, reiciendis earum explicabo ratione unde dolor autem quia laboriosam?
  						</li>
  					</ul>
  				</div>
  			</div>
  		</a>
  		<a href="#"><div class="info"></div></a>
  		<a href="#"><div class="info"></div></a>
  		<a href="#"><div class="info"></div></a>

  		<ul class="pagination">
		  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
		  <li class="page-item"><a class="page-link" href="#">1</a></li>
		  <li class="page-item"><a class="page-link" href="#">2</a></li>
		  <li class="page-item"><a class="page-link" href="#">3</a></li>
		  <li class="page-item"><a class="page-link" href="#">Next</a></li>
		</ul>
  </div>
<!-- -------------------------------------------------------------------------------------------------------- -->

<!-- --------------------------------------FOOTER-------------------------------------------------------- -->

  <div id="footer_container">
  	<div><a href="https://www.t.me/bureau_profiler" target="blank"><img src="head-hunt-images/telegram.png" alt="telegram"></a></div>
  	<div><a href="#"><img src="head-hunt-images/facebook.jpg" alt="facebook"></a></div>
  	<div><a href="#"><img src="head-hunt-images/twitter.png" alt="twitter"></a></div>
  </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

  </body>
</html>



