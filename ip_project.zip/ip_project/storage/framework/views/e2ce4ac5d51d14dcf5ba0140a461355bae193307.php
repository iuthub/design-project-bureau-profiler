<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
     <script src="js/fadeInScroll.jQuery.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
     <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('css/blog.css')); ?>">
     <title>Account</title>
  </head>
 


  
  <body>
		<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   


   










<div class="container-fluid" id="back-header">
<div class="container-inner">
<div class="header" >
 <img class="rounded-circle img-fluid" type="image" alt="Responsive image" src="images/user.png">
 <h2 class="header-font" id="mname">Shokhruh <span id="msurname">Shokhnazarov</span></h2>
 </div>
  </div>
</div>




<section class="blog_section">
<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>Headline</h2>
      <h6 id="mheadline">Guy next to me</h6>
    </div>
    <div class="card">
      <h2>Industry</h2>

        <textarea class="form-control" rows="3" id="mindustry" disabled="disabled" style="background-color:#fff; " placeholder=""></textarea>
      <h2 style="margin-top:5px">Work Experience</h2>

      <div class="form-group">

  <textarea class="form-control" rows="3" id="mexperience" disabled="disabled" style="background-color:#fff; " placeholder=""></textarea>
</div>
      
    </div>
 <div class="card">
      <h2>EDUCATION</h2>
     
        <textarea class="form-control" rows="3" id="meducation" disabled="disabled" style="background-color:#fff; " placeholder=""></textarea>
      <p>Some text..</p>
    </div>

  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>About Me</h2>
      <h5>Location</h5>
      <h6 id="mcity" style="height:100px;">Tashkent</h6>
      <h5>Hobby</h5>
      <p id="mhobby">Hobby hobby hobby..</p>
    </div>
    <div class="card">
      <h2 id="mzip_gallery">Zip Gallery</h2>
      <p id="mzip">Zip1</p>
     <p id="mzip">Zip2</p>
     <p id="mzip">Zip3</p>
    </div>
    <div class="card">
      <h2>More about me</h2>
      <p id="mmore">Follow this link</p>
    </div>
  </div>
</div>




</section>


<div id="footer_container">
    <div><a href="https://www.t.me/bureau_profiler" target="blank"><img src="head-hunt-images/telegram.png" alt="telegram"></a></div>
    <div><a href="#"><img src="head-hunt-images/facebook.jpg" alt="facebook"></a></div>
    <div><a href="#"><img src="head-hunt-images/twitter.png" alt="twitter"></a></div>
  </div>

 <script>

 


</script>

   <!-- jQuery library -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</script>
  </body>
</html>