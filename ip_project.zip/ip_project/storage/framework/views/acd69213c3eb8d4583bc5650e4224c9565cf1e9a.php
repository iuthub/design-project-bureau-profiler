<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale = 1">
        <title>Profiler</title>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous"/>

        <link rel="stylesheet" href="<?php echo e(asset('css/profiler.css')); ?>"/>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    </head>

    <body class="body">
                
                <div class = "header">
                    <div class = "container">
                    <h1 class="header__title">PROFILER</h1>
                    <h3 class="header_subtitle">own your portfolio</h3>
                    </div>
                </div>


                <div class="container">
                <form onSubmit={props.handleSubmition} class="profilerBody">
                <h3 class="h3">User Info</h3>
                <p class="p">Name: </p>
                <input class="Input" type="text" name="userName" placeholder='your name here' />
                <p class="p">Surename: </p>
                <input class="Input" type="text" name="userLastName" placeholder='your surename here' />
                
                <br/>
                <label class="btn btn-primary">
                <input type="file" id="file" accept="image/*" hidden={true}/>upload photo
                <span class="custom-file-control"></span>
                </label>
                
                <p class="p">Headline: </p>
                <input class="Input" type="text" name="userHeadLine" placeholder='create a great headline' />
                <p class="p">Education: </p>
                <input class="Input" type="text" name="Education" placeholder='where you have studied' />
                <h3 class="h3">Location </h3>
                <p class="p">Living Area: </p>
                <input class="Input" type="text" name="livingArea" placeholder='your living place' />
                <p class="p">ZipCode: </p>
                <input class="Input" type="text" name="ZipCode" placeholder='zipCode of your living place' />
                <h3 class="h3">Background</h3>
                <p class="p">Industry: </p>
                <input class="Input" type="text" name="Industry" placeholder='any  work experience?' />
                <p class="p">Experience: </p>
                <input class="Input" type="text" name="Experience" placeholder='what kind of skills you have?' />
                <p class="p">Media: </p>
                <input class="Input" type="text" name="media" placeholder='place a link to your media' /><br />
                <label class="btn btn-primary">
                <input type="file" id="file" accept=".zip .rar" hidden={true}/>upload your works
                <span class="custom-file-control"></span>
                </label>
                <br/>
                <h3 class="h3">Final step</h3><br/>
                <button class="btn btn-outline-success" name="submit">SUBMIT</button>
            </form>    
        </div>
    </body>
</html>