<ul class="nav justify-content-center">
    <li class="nav-item">
        <a class="nav-link active" href="/ip_Project/public/index">H</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/ip_Project/public/profiler">Profiler</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/ip_Project/public/head">Head Hunt</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/ip_Project/public/blog">Account</a>
    </li>
    </li>


      <ul class="nav justify-content-end">
      <li class="nav-item">
          <a href="#sign-container" class="nav-link" href="#">Login</a>
      </li>
         
    </ul>
  </ul>
