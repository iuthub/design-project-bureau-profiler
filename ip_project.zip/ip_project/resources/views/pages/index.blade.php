<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
     <script src="js/fadeInScroll.jQuery.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">


    <link rel="stylesheet" type="text/css"  href="{{asset('css/index.css')}}">

    

    <title>Bureu Profiler | BP</title>
  </head>
  <body >
		@include('include.navbar')
    
   

{{-- <ul class="nav justify-content-center">
      <li class="nav-item">
      <a class="nav-link active" href="/ip_Project/public/index">H</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/ip_Project/public/">Profiler</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/ip_Project/public/head">Head Hunt</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/ip_Project/public/">Blogosphere</a>
    </li>



<ul class="nav justify-content-end">
 <li class="nav-item">
      <a href="#sign-container" class="nav-link" href="#">Account</a>
    </li>
     
    </ul>
  </ul> --}}

  {{-- <ul class="nav justify-content-end">
      <li class="nav-item">
          <a href="#sign-container" class="nav-link" href="#">Account</a>
      </li>
         
    </ul>
  </ul>
      --}}
<!-- ------------------------------------------------------------------------------ -->

  	<!-- ------------------------------ Contact us Page------------------------------------------------------------------ -->
		<img id="feedback_button" src="head-hunt-images/feedback.png" data-toggle="modal" data-target="#myModal" alt="message">

		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" style="margin-right: 5px;">&times;</button>
						<h5 class="modal-title">
								Fill in the form and leave the message, we will respond as soon as possible.
						</h5>
					</div>
					<div class="modal-body">
							<form action="/action_page.php">
								<div class="form-group">
									<input type="name" class="form-control" id="name" placeholder="Enter your name">
								</div>
								<div class="form-group">
									<input type="email" class="form-control" id="email" placeholder="Enter your email address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Please,fill correctly" required>
								</div>
								<div class="form-group">
										<input type="text" class="form-control" id="text" placeholder="Subject of your message">
								</div>
								<div class="form-group">
										<textarea class="form-control" rows="5" id="comment" placeholder="Enter your message"></textarea>
								</div>
								<button type="submit" class="btn btn-default">Submit</button>
							</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
				
			</div>
		</div>
	
	<!-- -------------------------------------------------------------------------------------------- -->     


<img id="feedback_button" src="images/feedback.png" data-toggle="modal" data-target="#myModal" alt="message">

  
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" style="margin-right: 5px;">&times;</button>
          <h5 class="modal-title">
            Fill in the form and leave the message, we will respond as soon as possible.
          </h5>
        </div>
        <div class="modal-body">
          <form action="/action_page.php">
        <div class="form-group">
          <input type="name" class="form-control" id="name" placeholder="Enter your name">
        </div>
        <div class="form-group">
          <input type="email" class="form-control" id="email" placeholder="Enter your email address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Please,fill correctly" required>
        </div>
        <div class="form-group">
          <input type="text" class="form-control" id="text" placeholder="Subject of your message">
        </div>
        <div class="form-group">
          <textarea class="form-control" rows="5" id="comment" placeholder="Enter your message"></textarea>
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  







<div class="hero-image">
  <div class="hero-text">
     <p></p>;
  </div>
</div>











<section>

 <div class="parallax-container">
      <div class="parallax" style="background-image: url({{ asset('images/parallax-photo.png') }});">
        <img class="img-fluid " alt="Responsive image" src="images/leo.png">

      </div>
    </div>

<!--
<div class="parallax">
  <div class="parallax__group">
    <div class="parallax__layer parallax__layer--back">
       <a  href="production.html"><img  src="attributes/panorama.jpg" left="-3%" width="100%"  ></a>
         <div class="parallax_column" >
             
		 </div>


    </div>

   <div class="parallax__layer parallax__layer--base">
       <a href="production.html"><p class="parallax_title" >ABOUT US</p></a>

   </div>

 </div>
 
</div>
-->

<div class="d-flex justify-content-around bg mb-3" id="about_us">
  <span class="p-2 bg  border-bottom font-weight-bold">Point-by-point metrics</span>

  <span class="p-2 bg border-bottom font-weight-bold ">Art Station / Networking</span>
  <span class="p-2 bg border-bottom font-weight-bold">HR communication</span>
  
</div>

<div class="container-fluid text-center">
	<div class="row">
    <div class="col-sm-4 font-weight-light " >
      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br>
      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    </div>
    <div class="col-sm-4 font-weight-light " >
      Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto.  
    </div>
    <div class="col-sm-4 font-weight-light " >
      Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto.  
    </div>
</div>
</div>




<img src="images/tutor-photo.png" class="img-fluid" alt="Responsive image">

<div class="container-fluid text-center" id="partners">
 


  <p class="partner_header">WORKING COMMUNITIES</p>  
 	               

 <!--            
<div class="footer_elements"><a href ="#"><img alt="Responsive image" src="awwards-logo.png" width="44px"
  height="44px"></a></div>
-->

</div>




<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
   
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active" >
      <img class="d-block w-100" src="images/slide1.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
       <h5>Illustrations/Graphic Design</h5>
         <p>0 people</p>
    </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slide2.jpg"  alt="Second slide">
        <div class="carousel-caption d-none d-md-block">
       <h5>CGI / 3DModelling</h5>
         <p>1 people</p>
    </div>
   </div>


   
  

   
  </div>

  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<div class="container-fluid text-center" id="partners">

  <p class="partner_header">CONTACT US</p>  




</div>







</section>

<div class="container" id="sign-container">
    <div class="row">
        <div class="col col-sm-offset-4">
            
            <div class="inner_container">
                <img class="profile-img" src="images/user.png"
                    alt="">


                <form class="form-signin" action="/profiler">
                <input type="text" class="form-control" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Like radik51097@mail.ru" required  >
                <input name="password" type="password" id="_password" class="form-control" placeholder="Password" required  title="Password should be no more than 9 symbols" >
               
               
                <button class="btn btn-md btn-block" type="submit" id="sign_button" >
                    Log In</button>
                 <button  class="btn btn-md   btn-block btn  btn-outline-secondary"  type="submit" id="sign_button2">
                    Not registered yet?+</button>
          		
                </form>


           </div>
            
        </div>
    </div>
   </div>


 


                <form style="display: none;" class="form-signin2"  action="/profiler" method="POST">
                <input type="text" class="form-control" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Please,fill correctly" required  >
                <input name="password" type="password" id="password" class="form-control" placeholder="Password" required  pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{7,}$" title="At least 1 alphanumeric, 1 capital, 1 small and 7 in total" >
               <input name="password" type="password" id="confirm_password" class="form-control" placeholder="Repeat Password" required  >
               
                <button class="btn btn-md btn-block" type="submit" id="sign_button" >
                    Sign Up</button>
                 <button  class="btn btn-md  btn-block btn  btn-outline-secondary"  type="submit" id="sign_button3">
                    Log In</button>
          		<span id='message'></span>
                </form>

 
       
<footer>



</footer>


<!--
<footer class="container-fluid text-center" >
  <p>Online Store Copyright</p>  
  <form class="form-inline">Get deals:
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Sign Up</button>
  </form>
</footer>
-->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    



    <script>

        $(document).ready(function() {
       
       
       
       
       function func(){
          var hero1= $(".hero-text ");
       
          window.setTimeout(function(){ 
            hero1.html("We love Design");
       
            window.setTimeout(function(){ 
            hero1.html("We love Coding");
       
            window.setTimeout(function(){ 
            hero1.html("We love Swift");
       
            window.setTimeout(function(){ 
            hero1.html("We love Drawing");
       
            window.setTimeout(function(){ 
            hero1.html("We love Everyone");
       
            window.setTimeout(function(){ 
            hero1.html("and royalty");
       
             func();
       
           }
            ,500);
           }
            ,500);
           }
            ,500);
           }
            ,500);
          }
            ,500);
          }
            ,1000);
          }
         
          func();
           
       
         
       
       
         document.getElementById ("sign_button2").addEventListener ("click", first, true);
         document.getElementById ("sign_button3").addEventListener ("click", second, true);
       
       
        function first(){
         
                $(".form-signin").hide();
                
                $(".form-signin2").css("display", "");
       
         };
       
       
       function second(){
         
        
                $(".form-signin2").hide();
                $(".form-signin").show();
                
       
         };
       
       
         
       var password = document.getElementById("password")
       var confirm_password = document.getElementById("confirm_password");
       
       function validatePassword(){
         if(password.value != confirm_password.value) {
              $("#message").html("Not Matching").css("color", "red");
           confirm_password.setCustomValidity("Passwords Don't Match");
       
         } else {
           $("#message").html("Matching").css("color", "green");
           confirm_password.setCustomValidity('');
       
         }
       }
       
       password.onchange = validatePassword;
       confirm_password.onkeyup = validatePassword;
       
       
       
       });
       
        validatePassword();
       
       
       </script>  

   <!-- jQuery library -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </script>
  </body>
</html>